package org.pentaho.reporting.platform.plugin;

/**
 * Created by dima.prokopenko@gmail.com on 3/5/2016.
 */
public enum RenderType {
  REPORT, XML, PARAMETER, SUBSCRIBE, DOWNLOAD
}
