/*!
 * This program is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License, version 2.1 as published by the Free Software
 * Foundation.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * program; if not, you can obtain a copy at http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
 * or from the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * Copyright (c) 2002-2017 Hitachi Vantara..  All rights reserved.
 */

package org.pentaho.gwt.widgets.client.filechooser.images;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.google.gwt.user.client.ui.ImageBundle;
import com.google.gwt.user.client.ui.TreeImages;

public interface FileChooserImages extends ImageBundle, TreeImages {
  public static final FileChooserImages images = (FileChooserImages) GWT.create( FileChooserImages.class );

  AbstractImagePrototype file();

  AbstractImagePrototype file_waqr_report();

  AbstractImagePrototype file_pir_report();

  AbstractImagePrototype file_prpt_report();

  AbstractImagePrototype file_dashboard();

  AbstractImagePrototype file_analysis();

  AbstractImagePrototype file_analyzer();

  AbstractImagePrototype file_url();

  AbstractImagePrototype file_action();

  AbstractImagePrototype folder();

  AbstractImagePrototype up();

  AbstractImagePrototype search();
}
