/*
* Copyright 2002 - 2017 Hitachi Vantara.  All rights reserved.
*
* This software was developed by Hitachi Vantara and is provided under the terms
* of the Mozilla Public License, Version 1.1, or any later version. You may not use
* this file except in compliance with the license. If you need a copy of the license,
* please go to http://www.mozilla.org/MPL/MPL-1.1.txt. TThe Initial Developer is Pentaho Corporation.
*
* Software distributed under the Mozilla Public License is distributed on an "AS IS"
* basis, WITHOUT WARRANTY OF ANY KIND, either express or  implied. Please refer to
* the license for the specific language governing your rights and limitations.
*/

package org.pentaho.vfs.ui;

import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemManager;
import org.apache.commons.vfs2.FileSystemOptions;

/**
 * @author Andrey Khayrutdinov
 */
public class DelegatingResolver implements VfsResolver {

  private final FileSystemManager fsm;

  public DelegatingResolver( FileSystemManager fsm ) {
    if ( fsm == null ) {
      throw new NullPointerException( "A FileSystemManager is required" );
    }
    this.fsm = fsm;
  }

  @Override
  public FileObject resolveFile( String vfsUrl ) throws FileSystemException {
    return fsm.resolveFile( vfsUrl );
  }

  @Override
  public FileObject resolveFile( String vfsUrl, FileSystemOptions fsOptions ) throws FileSystemException {
    return fsm.resolveFile( vfsUrl, fsOptions );
  }
}
