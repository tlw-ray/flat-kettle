/*! ******************************************************************************
 *
 * Pentaho Data Integration
 *
 * Copyright (C) 2002-2017 by Hitachi Vantara : http://www.pentaho.com
 *
 *******************************************************************************
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ******************************************************************************/

package org.pentaho.metaverse.analyzer.kettle.jobentry;

import org.pentaho.di.job.entry.JobEntryInterface;
import org.pentaho.metaverse.api.IComponentDescriptor;
import org.pentaho.metaverse.api.IMetaverseNode;
import org.pentaho.metaverse.api.MetaverseAnalyzerException;
import org.pentaho.metaverse.api.analyzer.kettle.jobentry.JobEntryAnalyzer;

import java.util.Set;

/**
 * KettleGenericStepMetaAnalyzer provides a default implementation for analyzing PDI step to gather metadata for the
 * metaverse.
 */
public class GenericJobEntryMetaAnalyzer extends JobEntryAnalyzer<JobEntryInterface> {

  /**
   * Analyzes a step to gather metadata (such as input/output fields, used database connections, etc.)
   *
   * @see IAnalyzer#analyze(IComponentDescriptor, Object)
   */
  @Override
  public IMetaverseNode analyze( IComponentDescriptor descriptor, JobEntryInterface jobEntryInterface )
    throws MetaverseAnalyzerException {

    return super.analyze( descriptor, jobEntryInterface );
  }

  @Override
  public Set<Class<? extends JobEntryInterface>> getSupportedEntries() {
    return null;
  }

  @Override
  protected void customAnalyze( JobEntryInterface entry, IMetaverseNode rootNode ) throws MetaverseAnalyzerException {
    // TODO Auto-generated method stub

  }

}
