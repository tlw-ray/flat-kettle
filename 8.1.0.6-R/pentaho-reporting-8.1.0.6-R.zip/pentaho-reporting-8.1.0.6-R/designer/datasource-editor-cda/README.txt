Pentaho Reporting extensions
----------------------------

The classes in this subproject extend Pentaho Reporting with additional
functionality. Please refer to either the Pentaho Reporting Engine Core
or Pentaho Report-Designer for general details on the project and for the
latest Changes.


This extension module provides the following additional functionality:

 * A datasource-editor-UI-plugin for the external datasource.
 
