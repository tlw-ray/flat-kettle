return new Chart("Simple Bar Chart")
    .addElements(new BarChart(BarChart.Style.GLASS)
        .addValues(9, 8, 7, 6, 5, 4, 3, 2, 1));