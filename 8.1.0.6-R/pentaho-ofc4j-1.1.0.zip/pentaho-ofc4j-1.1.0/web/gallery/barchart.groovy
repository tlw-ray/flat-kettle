return new Chart("Simple Bar Chart")
    .addElements(new BarChart()
        .addValues(9, 8, 7, 6, 5, 4, 3, 2, 1));