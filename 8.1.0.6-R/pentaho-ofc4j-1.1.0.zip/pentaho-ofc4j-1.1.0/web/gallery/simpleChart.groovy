new Chart(new Date().toString())
    .addElements(new LineChart()
        .addValues(9,8,7,6,5,4,3,2,1));