package ofc4j.model;

public class Tooltip {

  private int mouse = 2;

  public int getMouse() {
    return mouse;
  }

  public void setMouse(int mouse) {
    this.mouse = mouse;
  }
}
