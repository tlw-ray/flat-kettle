pentaho-database-model
----------------------

Hive and Impala dialects have been moved to [the Pentaho Big Data Plugin](https://github.com/pentaho/big-data-plugin)
