var lib4 = "lib4: some external code!";
