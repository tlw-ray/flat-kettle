var lib7 = "lib7: some external code!";
