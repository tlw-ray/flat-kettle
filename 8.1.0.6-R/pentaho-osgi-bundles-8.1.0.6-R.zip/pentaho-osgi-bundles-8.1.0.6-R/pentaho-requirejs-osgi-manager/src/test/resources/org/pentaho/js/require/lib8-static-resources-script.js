var lib8 = "lib8: some external static code!";
