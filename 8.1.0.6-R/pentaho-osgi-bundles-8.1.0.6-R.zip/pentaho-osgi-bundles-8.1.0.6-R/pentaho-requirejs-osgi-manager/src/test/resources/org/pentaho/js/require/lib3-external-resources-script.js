var lib3 = "lib3: some external code!";
