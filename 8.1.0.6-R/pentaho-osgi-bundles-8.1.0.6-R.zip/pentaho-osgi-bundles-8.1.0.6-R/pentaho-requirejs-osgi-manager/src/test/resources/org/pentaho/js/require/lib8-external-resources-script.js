var lib8 = "lib8: some external code!";
