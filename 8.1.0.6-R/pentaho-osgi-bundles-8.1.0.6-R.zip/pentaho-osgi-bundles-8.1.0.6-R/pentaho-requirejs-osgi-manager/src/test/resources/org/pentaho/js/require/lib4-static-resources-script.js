var lib4 = "lib4: some external static code!";
