## Hitachi Vantara Spring Security Provider
This bundle contains a proxy class to bridge Authentication requests from outside of OSGI 
into the OSGI container to attempt authentication with the newer Spring Security.