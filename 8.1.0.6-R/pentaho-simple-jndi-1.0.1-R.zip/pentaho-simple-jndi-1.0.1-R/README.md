# pentaho-simple-jndi
Pentaho Fork of old Simple JNDI Project

Public wiki:
https://code.google.com/p/osjava/wiki/SimpleJNDI
License file:
https://code.google.com/p/osjava/source/browse/trunk/simple-jndi/LICENSE.txt?r=2680
