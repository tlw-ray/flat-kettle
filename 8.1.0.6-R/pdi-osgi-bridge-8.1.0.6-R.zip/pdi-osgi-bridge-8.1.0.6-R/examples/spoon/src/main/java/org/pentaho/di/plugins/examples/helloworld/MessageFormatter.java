package org.pentaho.di.plugins.examples.helloworld;

/**
 * User: nbaker Date: 1/30/11
 */
public interface MessageFormatter {

  String format( String message );
}
