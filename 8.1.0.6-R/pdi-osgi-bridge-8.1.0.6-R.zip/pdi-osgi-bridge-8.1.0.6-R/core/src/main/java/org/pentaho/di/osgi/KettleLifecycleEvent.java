package org.pentaho.di.osgi;

import org.pentaho.platform.servicecoordination.api.IPhasedLifecycleEvent;

/**
 * Created by nbaker on 2/18/15.
 */
public enum KettleLifecycleEvent {
    STOPPED, INIT, SHUTDOWN
}
