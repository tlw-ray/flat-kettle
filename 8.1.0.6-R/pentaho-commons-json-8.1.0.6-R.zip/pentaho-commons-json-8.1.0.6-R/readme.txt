This project contains json code.  Currently this
code is used within the pentaho-cdf and pentaho-dashboard project. This 
project is created primarily for packagign purposes as json does not provide
a jar.

