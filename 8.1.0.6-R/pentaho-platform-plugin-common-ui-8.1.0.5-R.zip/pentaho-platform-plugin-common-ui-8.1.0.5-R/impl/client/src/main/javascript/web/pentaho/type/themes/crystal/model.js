define([
  "css!./model.css"
], function() {
});
