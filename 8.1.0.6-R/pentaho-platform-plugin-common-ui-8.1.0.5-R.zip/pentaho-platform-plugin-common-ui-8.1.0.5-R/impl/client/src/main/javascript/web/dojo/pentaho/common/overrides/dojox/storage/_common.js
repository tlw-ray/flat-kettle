define("dojox/storage/_common", ["dojox/storage/Provider", "dojox/storage/manager", "dojox/storage/LocalStorageProvider"
//  ,"dojox.storage.GearsStorageProvider", "dojox.storage.WhatWGStorageProvider", "dojox.storage.FlashStorageProvider", "dojox.storage.BehaviorStorageProvider", "dojox.storage.CookieStorageProvider"
], function(provider, manager){
  dojox.storage.manager.initialize();
});

