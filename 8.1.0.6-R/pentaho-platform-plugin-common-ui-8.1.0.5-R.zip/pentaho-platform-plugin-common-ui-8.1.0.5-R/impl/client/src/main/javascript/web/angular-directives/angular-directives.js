/* This controls the js-build of the directives into a single file */
define("common-ui/angular-directives/angular-directives",[
    "common-ui/angular-directives/accordionWizard/accordionWizard",
    "common-ui/angular-directives/folderBrowser/folderBrowser",
    "common-ui/angular-directives/angular-dojo/angular-dojo",
    "common-ui/angular-directives/dateTimePicker/dateTimePicker",
    "common-ui/angular-directives/recurrence/recurrence",
    "common-ui/angular-directives/schedule/scheduleSelector"
]);
